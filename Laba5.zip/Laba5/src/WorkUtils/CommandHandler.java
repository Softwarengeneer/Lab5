package WorkUtils;


import exception.IncorrectValue;
import exception.NoArgument;
import Input.IOInterface;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CommandHandler {
    private final DragonCollection dragon;
    CollectionManager manager;
    CommandReader reader = new CommandReader();
    private String[] rightCommand;

    public CommandHandler(DragonCollection dragon, String file) {
        this.dragon = dragon;
        this.manager = new CollectionManager(dragon, file);
    }

    public void doCommand(IOInterface inputCommand) throws IOException,NoArgument, IncorrectValue {
        this.rightCommand = this.reader.returnCommand(inputCommand);
        String var2 = this.rightCommand[0];
        switch(var2.hashCode()) {


            case -1020102443:
                if (var2.equals("execute_script")) {
                    try {
                        if (this.rightCommand.length < 2) {
                            throw new NoArgument("Вы должны ввести имя скрипта");
                        }

                        this.manager.executeScript(this.rightCommand[1]);
                    } catch (NoArgument var6) {
                        var6.getMessage();
                    } catch (FileNotFoundException var7) {
                        System.out.println("Такой файлик не найден");
                    }
                }
                break;
            case -838846263:
                try {
                    if (this.rightCommand.length < 2) {
                        throw new NoArgument("Вы должны ввести айди");
                    }

                    // this.manager.update(Integer.parseInt(this.rightCommand[1]), inputCommand);
                } catch (NoArgument var12) {
                    var12.getMessage();
                } catch (NumberFormatException var13) {
                    System.out.println("Мэн, введи число");
                }

                break;
            case -526296440:
                if (var2.equals("remove_by_id")) {
                    try {
                        if (this.rightCommand.length < 2) {
                            throw new NoArgument("Вы должны ввести айди");
                        }

                        this.manager.removeById(Integer.parseInt(this.rightCommand[1]));
                    } catch (NoArgument var9) {
                        var9.getMessage();
                    } catch (NumberFormatException var10) {
                        System.out.println("Мэн, введи число");
                    } catch (Exception var11) {
                        System.out.println("Такой элементик не найден");
                    }
                }
                break;
            case 0:
                break;
            case 96417:
                if (var2.equals("add")) {
                    this.manager.add(inputCommand);
                }
                break;
            case 3127582:
                if (var2.equals("exit")) {
                    System.exit(0);
                }
                break;
            case 3198785:
                if (var2.equals("help")) {
                    this.manager.help();
                }
                break;
            case 3237038:
                if (var2.equals("info")) {
                    this.manager.info();
                }
                break;
            case 3522941:
                if (var2.equals("save")) {
                    try {
                        this.manager.save();
                    } catch (Exception var8) {
                        System.out.println("Не могу сохранить:" + var8.getMessage());
                    }
                }
                break;
            case 3529469:
                if (var2.equals("show")) {
                    this.manager.show();
                }
                break;

            case 94746189:
                if (var2.equals("clear")) {
                    this.manager.clear();
                }
                break;

            default:
                System.out.println("Такой команды нет.");
        }


    }
}

