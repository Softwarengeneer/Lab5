package WorkUtils;



import CollectionElements.*;
import CollectionElements.Dragon;
import exception.IncorrectValue;
import exception.NoArgument;
import Input.FileInput;
import Input.IOInterface;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Vector;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;




public class CollectionManager {

    private String file;
    private DragonCollection dragon;
    public CommandHandler handler;


    public CollectionManager(DragonCollection dragon, String file) {
        this.dragon = dragon;
        this.file = file;
    }

    public void help() {
        System.out.println("help: Вывести справку по доступным командам" +
                " \ninfo: Вывести информацию о коллекции " +
                "\nadd: Добавить новый элемент в коллекцию " +
                "\nupdate id: Обновить значение элемента коллекции, id которого равен заданному"+
                "\n update_by_id {element}: обновить значение элемента коллекции по id"+
                "\n remove_by_id id: Удалить элемент из коллекции по его id"+
                "\n clear: Очистить коллекцию"+
                "\n save: Сохранить коллекцию в файл"+
                "\n execute_script file_name: Считать и исполнить скрипт из указанного файла"+
                " \n exit: Завершить программу (без сохранения в файл)"+
                " \n remove_first: Удалить из коллекции первый элемент"+
                "\n head: вывести первый элемент коллекции" +
                "\n history: вывести последние 9 команд"+
                "\n sum_of_age: вывести сумму значений поля для всех элементов коллекции"+
                "\n filter_by_type: вывести элементы, значение поля type которых равно заданному"+
                "\n filter_contains_name name: вывести элементы, значение поля name которых имеет заданную подстроку");
    }

    public void info() {
        System.out.println(this.dragon.toString());
    }

    public void show() {
        if (this.dragon.getDragons().size() != 0) {
            this.dragon.getDragons().forEach(System.out::println);
        } else {
            System.out.println("Коллекция пуста.");
        }

    }

    public Dragon readElement(IOInterface command) throws IncorrectValue {
        Dragon h = null;
        Color hairColor = null;
        Color eyeColor = null;
        Color color = null;
        DragonCharacter character = null;
        DragonType type = null;

        try {
            String name;
            do {
                command.output("Введите имя:");
                name = command.getNextInput().trim();
            } while (name.equals(""));

            int x = 0;

            do {
                command.output("Введите координаты, x:");
                String x1 = command.getNextInput().trim();
                if (x1.matches("[-+]?\\d+")) {
                    x = Integer.parseInt(x1);
                    if (x < -658) {
                        x = 0;
                        System.out.println("Поле должно быть больше -658");
                    }
                }
            } while (x == 0);

            double y = 0.0;


            do {
                command.output("y:");
                String y1 = command.getNextInput();
                if (y1.matches("((-|\\\\+)?[0-9]+(\\\\.[0-9]+)?)+")) {
                    y = Double.parseDouble(y1);
                    if (y < 649.0) {
                        y = 0.0;
                        System.out.println("Максимальное значение y - 649");
                    }
                }
            } while (y == 0.0);
            int age = 0;

            do {
                command.output("Введите возрвст дракона:");
                String AAge = command.getNextInput().trim();
                if (AAge.matches("[-+]?\\d+")) {
                    age = Integer.parseInt(AAge);
                    if (age < 0) {
                        age = 0;
                        System.out.println("Возраст должен быть больше 0, ты шо, глупый?(");
                    }
                }
            } while (age == 0);


            String answer1;
            do {
                command.output("Выберите цвет дракона: BROWN, ORANGE, BLUE, RED, WHITE");
                answer1 = command.getNextInput().trim();
                switch (answer1.hashCode()) {
                    case 94011702:
                        if (answer1.equals("brown")) {
                            color= Color.BROWN;
                        }
                        break;
                    case -1008851410:
                        if (answer1.equals("orange")) {
                            color=Color.ORANGE;
                        }
                        break;
                    case 0:
                        if (answer1.equals("")) {
                            color=null;
                        }
                        break;
                    case 3027034:
                        if (answer1.equals("blue")) {
                            color=Color.BLUE;
                        }
                        break;
                    case 112785:
                        if (answer1.equals("red")) {
                            color=Color.RED;
                        }
                    case 113101865:
                        if (answer1.equals("white")){
                            color=Color.WHITE;
                        }
                    default:
                        command.output("Такого варианта нет");
                }


            } while (!answer1.toLowerCase().equals("calm") && !answer1.toLowerCase().equals("frenzy") && !answer1.toLowerCase().equals("sadness") && !answer1.toLowerCase().equals("apathy") && !answer1.equals(""));

            // CORRECT NEED
            String answer2;
            do {
                command.output("Выберите тип дракона: WATER, UNDERGROUND, AIR,");
                answer2 = command.getNextInput().trim();
                switch (answer2.hashCode()) {
                    case 112903447:
                        if (answer2.equals("water")) {
                            type = DragonType.WATER;
                        }
                        break;
                    case 795515487:
                        if (answer2.equals("underground")) {
                            type = DragonType.UNDERGROUND;
                        }
                        break;
                    case 0:
                        if (answer2.equals("")) {
                            type = null;
                        }
                        break;
                    case 96586:
                        if (answer2.equals("air")) {
                            type = DragonType.AIR;
                        }
                        break;
                    default:
                        command.output("Такого варианта нет");
                }




            } while (!answer2.toLowerCase().equals("air") && !answer2.toLowerCase().equals("underground") && !answer2.toLowerCase().equals("water")  && !answer2.equals(""));
            //CORRECT NEED

            String answer3;
            do {
                command.output("Выберите характер дракона: CUNNING, CHAOTIC, EVIL, WISE, FICKLE");
                answer3 = command.getNextInput().trim();

                switch (answer3.hashCode()) {
                    case 3125652:
                        if (answer3.equals("evil")) {
                            character = DragonCharacter.EVIL;
                        }
                        break;
                    case 1123130608:
                        if (answer3.equals("cunning")) {
                            character = DragonCharacter.CUNNING;
                        }
                        break;
                    case 0:
                        if (answer3.equals("")) {
                            character = null;
                        }
                        break;
                    case -1274768604:
                        if (answer3.equals("fickle")) {
                            character = DragonCharacter.FICKLE;
                        }
                        break;
                    case 738986075:
                        if (answer3.equals("Chaotic")) {
                            character = DragonCharacter.CHAOTIC;
                        }
                    case 3649700:
                         if (answer3.equals("wise")){
                             character=DragonCharacter.WISE;
                         }
                    default:
                        command.output("Такого варианта нет");
                }


            } while (!answer3.toLowerCase().equals("fickle") && !answer3.toLowerCase().equals("evil") && !answer3.toLowerCase().equals("chaotic") && !answer3.toLowerCase().equals("cunning") && !answer3.equals(""));
            command.output("Введите имя киллера:");
            String nameOfPerson = command.getNextInput().trim();
            int height = 0;

            do {
                command.output("Введите рост киллера:");
                String Height = command.getNextInput().trim();
                if (Height.matches("[-+]?\\d+")) {
                    height = Integer.parseInt(Height);
                    if (height < 0) {
                        x = 0;
                        System.out.println("Рост должен быть больше 0, ты шо, глупый?(");
                    }
                }
            } while (height == 0);


            String answer4;
            do {
                command.output("Выберите цвет глазиков:");
                answer4 = command.getNextInput().trim();

                switch (answer4.hashCode()) {
                    case 94011702:
                        if (answer4.equals("brown")) {
                            eyeColor = Color.BROWN;
                        }
                        break;
                    case -1008851410:
                        if (answer4.equals("orange")) {
                            eyeColor = Color.ORANGE;
                        }
                        break;
                    case 0:
                        if (answer4.equals("")) {
                            eyeColor = null;
                        }
                        break;
                    case 3027034:
                        if (answer4.equals("blue")) {
                            eyeColor = Color.BLUE;
                        }
                        break;
                    case 112785:
                        if (answer4.equals("red")) {
                            eyeColor = Color.RED;
                        }
                    case 113101865:
                        if (answer4.equals("white")){
                            eyeColor= Color.WHITE;
                        }
                    default:
                        command.output("Такого варианта нет");
                }


            } while (!answer4.toLowerCase().equals("white") && !answer4.toLowerCase().equals("orange") && !answer4.toLowerCase().equals("brown") && !answer4.toLowerCase().equals("blue") && !answer4.equals("") && !answer4.toLowerCase().equals("red"));


            String answer5;
            do {
                command.output("Выберите цвет волосни:");
                answer5 = command.getNextInput().trim();

                switch (answer5.hashCode()) {
                    case 94011702:
                        if (answer5.equals("brown")) {
                            hairColor = Color.BROWN;
                        }
                        break;
                    case -1008851410:
                        if (answer5.equals("orange")) {
                            hairColor = Color.ORANGE;
                        }
                        break;
                    case 0:
                        if (answer5.equals("")) {
                            hairColor = null;
                        }
                        break;
                    case 3027034:
                        if (answer5.equals("blue")) {
                            hairColor = Color.BLUE;
                        }
                        break;
                    case 112785:
                        if (answer5.equals("red")) {
                            hairColor = Color.RED;
                        }
                    case 113101865:
                        if (answer5.equals("white")){
                            hairColor= Color.WHITE;
                        }
                    default:
                        command.output("Такого варианта нет");
                }

            } while (!answer5.toLowerCase().equals("white") && !answer5.toLowerCase().equals("orange") && !answer5.toLowerCase().equals("brown") && !answer5.toLowerCase().equals("blue") && !answer5.equals("") && !answer5.toLowerCase().equals("red"));



            int xL = 0;

            do {
                command.output("Введите координаты, x:");
                String XX = command.getNextInput().trim();
                if (XX.matches("[-+]?\\d+")) {
                    xL = Integer.parseInt(XX);
                    if (xL < -658) {
                        xL = 0;
                        System.out.println("Поле должно быть больше -658");
                    }
                }
            } while (xL == 0);

            int yL = 0;


            do {
                command.output("y:");
                String YY = command.getNextInput();
                if (YY.matches("((-|\\\\+)?[0-9]+(\\\\.[0-9]+)?)+")) {
                    yL = Integer.parseInt(YY);
                    if (yL < 649) {
                        yL = 0;
                        System.out.println("Максимальное значение y - 649");
                    }
                }
            } while (yL == 0);

            long zL = 0;


            do {
                command.output("y:");
                String ZZ = command.getNextInput();
                if (ZZ.matches("((-|\\\\+)?[0-9]+(\\\\.[0-9]+)?)+")) {
                    zL = Long.parseLong(ZZ);
                    if (zL < 649) {
                        zL = 0;
                        System.out.println("Максимальное значение y - 649");
                    }
                }
            } while (zL == 0);

            command.output("Введите имя локации:");
            String nameOfLocation = command.getNextInput().trim();

            h = new Dragon(name, new Coordinates(x, y), age, color, type, character, new Person(nameOfPerson, height, eyeColor, hairColor, new Location(xL, yL, zL, nameOfLocation)));

        } catch (NullPointerException var30) {
            System.out.println("Ошибки в скрипте");
        }

        return h;
    }


    public void add(IOInterface c) throws IncorrectValue {
        this.dragon.getDragons().add(this.readElement(c));
    }

    public void removeById(int id) {
        int k = 0;

        int i;
        for (i = 0; i < this.dragon.getDragons().size(); ++i) {
            if (this.dragon.getDragons().get(i).getId() == id) {
                ++k;
            }
        }

        if (k > 0) {
            for (i = 0; i < this.dragon.getDragons().size(); ++i) {
                if (this.dragon.getDragons().get(i).getId() == id) {
                    this.dragon.getDragons().remove(i);
                }
            }

            System.out.println("Элемент коллекции удалён.");
        } else {
            System.out.println("Такого id нет");
        }

    }

    public void clear() {
        this.dragon.getDragons().clear();
        System.out.println("Коллекция очищена.");
    }

    public void save() throws JAXBException, IOException {
        FileWriter writer = new FileWriter(this.file);
        JAXBContext context1 = JAXBContext.newInstance(DragonCollection.class);
        Marshaller marshaller = context1.createMarshaller();
        marshaller.marshal(this.dragon, writer);
        marshaller.marshal(this.dragon, new File(this.file));
        System.out.println("Сохранено!");
        writer.close();
    }

    public void executeScript(String fileName) throws IOException, IncorrectValue {
        CommandHandler handler = new CommandHandler(this.dragon, this.file);
        FileInput input = new FileInput(fileName);

        try {
            while (input.getNextInput() != null) {
                if (input.getCurrentInput().equals("execute_script " + fileName)) {
                    throw new IncorrectValue("Он пытался сломать меня... Вот *****");
                }

                handler.doCommand(input);
            }
        } catch (IncorrectValue | NoArgument var5) {
            var5.getMessage();
        }

    }




    public void sumOfAge() {
        long k = 0L;

        for (int i = 0; i < this.dragon.getDragons().size(); ++i) {
            k += this.dragon.getDragons().get(i).getAge();
        }

        System.out.println("Сумма значений полей Age = " + k);
    }


}


