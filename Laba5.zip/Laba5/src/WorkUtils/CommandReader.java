package WorkUtils;

import Input.IOInterface;

public class CommandReader {
    public String[] returnCommand(IOInterface inputCommand) {
        return inputCommand.getCurrentInput().toLowerCase().trim().split(" ", 2);
    }
}