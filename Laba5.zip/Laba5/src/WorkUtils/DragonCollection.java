package WorkUtils;

import CollectionElements.Dragon;
import java.util.Date;
import java.util.Vector;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(
        name = "dragonLife"
)
@XmlAccessorType(XmlAccessType.FIELD)
public class DragonCollection {
    @XmlElement(
            name = "Dragon"
    )
    public Vector<Dragon> dragon;
    private Date date;

    public Vector<Dragon> getDragons() {
        return this.dragon;
    }

    public Vector<Dragon> getCollection() {
        return this.dragon;
    }

    public DragonCollection(Vector<Dragon> dragon) {
        this.dragon = dragon;
        this.date = new Date();
    }
    public DragonCollection(){

    }


    public String toString() {
        return "Тип коллекции: " + this.getCollection().getClass() + "\nДата инициализации: " + this.date + "\nКоличество элементов: " + this.getCollection().size();
    }



    public void setDate(Date date) {
        this.date = date;
    }
}

