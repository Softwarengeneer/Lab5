package CollectionElements;



import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Person {
    private String name;
    private int height;
    private Color eyeColor;
    private Color hairColor;
    private Location location;

    public Person(String name, int height, Color eyeColor, Color hairColor, Location location) {
        this.name = name;
        this.height = height;
        this.eyeColor= eyeColor;
        this.hairColor= hairColor;
        this.location= location;
    }
    public Person(){

    }

    public String getName() {
        return this.name;
    }

    public String toString() {
        return "Person{name='" + this.name + '\'' + "height=" + this.height + '}';
    }


    public int getHeight() {
        return this.height;
    }
    public Color eyeColor(){
        return this.eyeColor;
    }
    public Location getLocation() {
        return this.location;
    }
    public Color getHairColor(){
        return this.hairColor;
    }

}