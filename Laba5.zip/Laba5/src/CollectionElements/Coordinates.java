package CollectionElements;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Coordinates {
    private int x;
    private Double y;

    public Coordinates(int x, Double y) {
        this.x = x;
        this.y = y;
    }
    public Coordinates(){
    }

    public int getX() {
        return this.x;
    }

    public Double getY() {
        return this.y;
    }

    public String toString() {
        return "[x=" + this.getX() + ", y=" + this.getY() + "]";
    }
}

