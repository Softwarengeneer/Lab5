package CollectionElements;

public enum DragonType {
    WATER,
    UNDERGROUND,
    AIR
}