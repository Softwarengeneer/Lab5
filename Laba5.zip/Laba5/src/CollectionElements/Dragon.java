package CollectionElements;



import java.time.LocalDate;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(
        name = "dragonLife"
)
@XmlAccessorType(XmlAccessType.FIELD)
public class Dragon implements Comparable<Dragon> {
    private int id; // Значение поля должно быть больше 0, быть уникальным и генерироваться автоматически.
    private String name;//Строка не может быть пустой
    private Coordinates coordinates; // Не может быть null
    @XmlJavaTypeAdapter(LocalDateSerializer.class)
    private LocalDate creationDate; // Генерируется автоматически, не может быть null
    private Integer age; //может быть null, должно быть больше нуля
    private Color color; // может быть null
    private DragonType type; // не может быть null
    private DragonCharacter character;// поле не может быть null
    private Person killer; // может быть null

    public Dragon(){
    }

    public void setId(int id){
        this.id=id;
    }


    public int getId() {
        return this.id;
    }
    public String getName() {
        return this.name;
    }
    public Coordinates getCoordinates() {
        return this.coordinates;
    }
    public LocalDate getCreationDate() {
        return this.creationDate;
    }
    public Integer getAge(){
        return this.age;
    }
    public Color getColor(){
        return this.color;
    }
    public DragonType getType(){ return this.type;}
    public DragonCharacter getCharacter(){ return this.character;}
    public Person getKiller() { return killer;}

    public Dragon(String name, Coordinates coordinates, Integer age, Color color, DragonType type, DragonCharacter character, Person killer  ) {
        this.id = (int)(Math.random() * 1000.0D);
        this.name = name;
        this.coordinates = coordinates;
        this.creationDate = LocalDate.now();
        this.age=age;
        this.color=color;
        this.type=type;
        this.character=character;
        this.killer=killer;


    }

    public String toString() {
        return "DragonLife{id=" + this.id
                + ", name='" + this.name + '\'' +
                ", coordinates=" + this.coordinates +
                ", creationDate=" + this.creationDate +
                ", Age=" + this.age+
                ", Color="+ this.color+
                ", DragonType="+this.type+
                ", DragonCharacter="+this.character+
                ", Person="+this.killer +'}';
    }


    @Override
    public int compareTo(Dragon o) {
        return 0;
    }
}
