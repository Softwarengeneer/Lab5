package CollectionElements;

public enum DragonCharacter {
    CUNNING,
    WISE,
    EVIL,
    CHAOTIC,
    FICKLE
}