package CollectionElements;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Location {
    private Integer x;
    private Integer y;
    private long z;
    private String name;

    public Location(Integer x,Integer y, long z, String name){
        this.name=name;
        this.x=x;
        this.y=y;
        this.z=z;

    }
    public String toString(){
        return "Location{x="+this.x + ", y= " + this.y + "z="+ this.z + "name"+ this.name + "}";

    }



    public Integer getX(){
        return x;
    }
    public void setX(Integer x){
        this.x=x;
    }


    public Integer getY(){
        return y;
    }
    public void setY(Integer y){
        this.y=y;
    }


    public long getZ(){
        return z;
    }

    public void setZ(long z) {
        this.z = z;
    }

    public String getLocationName(){
        return name;
    }
    public void setLocationName(String name){
        this.name=name;
    }
}