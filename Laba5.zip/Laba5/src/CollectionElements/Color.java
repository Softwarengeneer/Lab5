package CollectionElements;

public enum Color {
    RED,
    BLUE,
    ORANGE,
    WHITE,
    BROWN
}