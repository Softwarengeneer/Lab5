package exception;

public class NoArgument extends Exception {
    public NoArgument(String s) {
        System.out.println(s);
    }
}
