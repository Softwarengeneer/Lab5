package exception;

public class NoCorrectValue extends Exception {
    public NoCorrectValue(String s) {
        super(s);
    }
}