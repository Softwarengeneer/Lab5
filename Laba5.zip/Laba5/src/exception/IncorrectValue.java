package exception;

public class IncorrectValue extends Exception {
    public IncorrectValue(String message) {
        System.out.println(message);
    }
}