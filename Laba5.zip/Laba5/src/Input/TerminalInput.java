package Input;

import java.util.Scanner;

public class TerminalInput implements IOInterface {
    private String currentInput;

    public String getNextInput() {
        Scanner sc = new Scanner(System.in);
        this.currentInput = sc.nextLine().trim();
        return this.currentInput;
    }

    public String getCurrentInput() {
        return this.currentInput;
    }

    public void output(String message) {
        System.out.println(message);
    }

    public Double getNextDoubleInput() {
        Scanner sc = new Scanner(System.in);
        return sc.nextDouble();
    }

    public Long getNextLongInput() {
        Scanner sc = new Scanner(System.in);
        return sc.nextLong();
    }
}

