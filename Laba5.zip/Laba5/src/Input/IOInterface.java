package Input;

public interface IOInterface {
    String getNextInput();

    String getCurrentInput();

    void output(String var1);

    Double getNextDoubleInput();

    Long getNextLongInput();
}