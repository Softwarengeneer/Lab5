package Input;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileInput implements IOInterface {
    private Scanner in;
    private String fileLine;

    public FileInput(String fileName) throws FileNotFoundException {
        this.in = new Scanner(new File(fileName));
    }

    public String getNextInput() {
        if (this.in.hasNext()) {
            this.fileLine = this.in.nextLine().toLowerCase();
            System.out.println(this.fileLine);
            return this.fileLine;
        } else {
            return null;
        }
    }

    public String getCurrentInput() {
        return this.fileLine;
    }

    public void output(String message) {
    }

    @Override
    public Double getNextDoubleInput() {
        return this.in.nextDouble();
    }

    public Long getNextLongInput() {
        return this.in.nextLong();
    }
}
